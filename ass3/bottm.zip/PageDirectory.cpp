#include "PageDirectory.h"

PageDirectory::PageDirectory(uint32_t pFCount)
{
    frames = pFCount;
    pTCount = 1024;
    pageTables = new PageTable* [pTCount];
    lastCyclesRan = 0;
    memAccesses = 0;
}

PageDirectory::~PageDirectory()
{
    delete[] pageTables;
}

PageTable* PageDirectory::getPageTable(uint32_t spot)
{
    lastCyclesRan++;
    createTable(spot);
    memAccesses++;
    lastTable = pageTables[spot];
    return pageTables[spot];
}

void PageDirectory::createTable(uint32_t spot)
{
    //only creates a table if we have not made one yet
    if(binarySearch(createdSpots, 0, createdSpots.size(), spot) == -1)
    {
        lastCyclesRan++;
        std::cout << "making new table!\n";
        pageTables[spot] = new PageTable(frames);
        memAccesses++;
        createdSpots.push_back(spot);
        std::sort(createdSpots.begin(), createdSpots.end());
    }
}

uint32_t PageDirectory::getLastCyclesRan()
{
    uint32_t last = lastCyclesRan;
    lastCyclesRan = 0;
    return last;
}

uint32_t PageDirectory::getMemAccesses()
{
    uint32_t mem = memAccesses;
    memAccesses = 0;
    return mem;
}

uint32_t PageDirectory::getTotalSwapIns()
{
    uint32_t total = 0;
    for(int i = 0; i < createdSpots.size(); i++)
    {
        total += pageTables[createdSpots[i]]->getSwapIns();
    }
    return total;
}

uint32_t PageDirectory::getTotalSwapOuts()
{
    uint32_t total = 0;
    for(int i = 0; i < createdSpots.size(); i++)
    {
        total += pageTables[createdSpots[i]]->getSwapOuts();
    }
    return total;
}

uint32_t PageDirectory::getMallocedPages()
{
    uint32_t total = 0;
    for(int i = 0; i < createdSpots.size(); i++)
    {
        total += pageTables[createdSpots[i]]->getPagesMalloced();
    }
    return total;
}

uint32_t PageDirectory::getPageTableCount()
{
    return pTCount;
}

uint32_t* PageDirectory::getWorkingSetSize()
{
    uint32_t* workingSets = new uint32_t[3];
    workingSets[1] = 0;
    for(int i = 0; i < createdSpots.size(); i++)
    {
        uint32_t curr = pageTables[createdSpots[i]]->getWorkingSetSize();
        if(workingSets[1] < curr)
        {
            workingSets[1] = curr;
            workingSets[2] = curr;
        }
    }
    workingSets[0] = lastTable->getWorkingSetSize();
    return workingSets;
}

int PageDirectory::binarySearch(std::vector<uint32_t> arr, int l, int r, int x)
{
    if(arr.size() == 1)
    {
        return 0;
    }
    if(arr.size() > 1)
    {
        while (l <= r)
        {
            int m = l + (r - l) / 2;
            if (arr[m] == x)
                return m;
            if (arr[m] < x)
                l = m + 1;
            else
                r = m - 1;
        }
    }

    return -1;
}

uint32_t PageDirectory::getFrames()
{
    return frames;
}
