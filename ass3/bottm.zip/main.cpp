#include <iostream>
#include "Page.h"
#include "PageTable.h"
#include "PageDirectory.h"
#include "vmm.h"
#include <cstdlib>
#include <time.h>
#include <fstream>

void test();
void pageStats(vmm* machine);
uint32_t parseString(std::string s);

int main(int argc, char* argv[])
{
    std::ifstream ifs;
    std::ofstream ofs;
    bool fileoutput = false;

    srand(time(0));
    if(argc == 2)
    {
        ifs.open(argv[1]);
    }
    else if(argc == 3)
    {
        ifs.open(argv[1]);
        ofs.open(argv[2]);
        fileoutput = true;
    }
    else
    {
        ifs.open("input.txt");
    }

    std::string input;
    ifs >> input;
    uint32_t frames;
    if(input == "p")
    {
        ifs >> input;
        frames = parseString(input);
    }

    vmm machine(frames);

    uint32_t line = 2;
    while(ifs >> input)
    {
        if(input == "r")
        {
            ifs >> input;
            uint32_t address = parseString(input);
            if(fileoutput)
            {
                ofs << "read: " << machine.read(address) << " at " << address
                    << "\n";
            }
            else
            {
                std::cout << "read: " << machine.read(address) << " at " << address
                     << "\n";
            }
        }
        else if(input == "w")
        {
            ifs >> input;
            uint32_t address = parseString(input);
            ifs >> input;
            uint32_t val = parseString(input);

            if(fileoutput)
            {
                ofs << "write: " << val << " at " << address << "\n";
            }
            else
            {
                std::cout << "write: " << val << " at " << address << "\n";
            }
        }
        else
        {
            std::cout << "error, bad input on line: " << line;
            break;
        }
        line++;
    }

    pageStats(&machine);

    ifs.close();
    ofs.close();
    return 0;
}

uint32_t parseString(std::string s)
{
    uint32_t sum = 0;
    for(int i = 0; i < s.size(); i++)
    {
        if(s[i] >= 48 && s[i] <= 57)
            sum = (sum * 10) + (s[i] - 48);
    }
    return sum;
}

void test()
{
    srand((unsigned)time(nullptr));
    vmm machine(9);

    machine.write(0x00000000, 24);
    machine.write(0x00001000, 2);
    machine.write(0x00002000, 4);
    machine.write(0x00003000, 21);

    for(uint32_t i = 0; i < 80; i++)
    {
        machine.write(i << (rand() % 16), i);
        std::cout << machine.read(i<<(rand() % 16)) << std::endl;
    }

    pageStats(&machine);
}

void pageStats(vmm* machine)
{
    std::cout << "* * * Paging Activity Statistics * * *\n";
    std::cout << "number of memory accesses       = " << machine->getAccesses()
        << "\n";
    std::cout << "number of triples               = " << machine->getAccesses()
        + 1 << "\n";
    std::cout << "number of swap-ins (faults)     = " << machine->pdSwapIns()
        << "\n";
    std::cout << "number of swap-outs             = " << machine->pdSwapOuts()
        << "\n";
    std::cout << "total number of pages malloced  = " << machine->pdMallocedPages()
        << "\n";
    std::cout << "number of pages for Page Tables = 1\n";
    std::cout << "number of page frames for user  = " << machine->getFrames()
        << "\n";
    std::cout << "total memory cycles             = " << machine->getCycles()
        << "\n";
    std::cout << "cycles w/o Vmm                  = " << machine->getAccesses() * 10
        << "\n";
    std::cout << "cycles per swap_in              = 5000\n";
    std::cout << "cycles per swap_out             = 5000\n";

    //make sure to delete as it returns a heap array
    uint32_t* sets = machine->getMaxWorkingSetSize();
    std::cout << "last working set size           = " << sets[0] << "\n";
    std::cout << "max working set size ever       = " << sets[1] << "\n";
    std::cout << "max physical pages              = " << sets[2] << "\n";
    delete[] sets;

    std::cout << "page size                       = 4096\n";
    std::cout << "repalcement algorithm           = random\n";
    std::cout << "Address range                   = " << " . . . \n";
}


/*
int main()
{
    PageDirectory pd;

    pd.createTable(0, 9);
    uint32_t addr = 5;

    std::cout << pd.getPageTable(0)->getPageCount() << std::endl;
    for(int i = 0; i < 9; i++)
    {
        pd.getPageTable(0)->createPage();
        pd.getPageTable(0)->swap();
        std::cout << "addr: " << pd.getPageTable(0)->getAddr() << std::endl;
    }

    return 0;
}
 */
